import React, { useEffect, useRef, useState } from 'react';
import { Wine, ShieldCheck, Truck, Clock4 } from 'lucide-react';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const productRefs = useRef<(HTMLDivElement | null)[]>([]);
  const featureRefs = useRef<(HTMLDivElement | null)[]>([]);
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              entry.target.classList.add('visible');
            }
          });
        },
        { threshold: 0.1 }
      );

      productRefs.current.forEach((ref) => {
        if (ref) observer.observe(ref);
      });

      featureRefs.current.forEach((ref) => {
        if (ref) observer.observe(ref);
      });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const { clientX, clientY } = e;
        const { innerWidth, innerHeight } = window;
        const moveX = (clientX - innerWidth / 2) / innerWidth * 20;
        const moveY = (clientY - innerHeight / 2) / innerHeight * 20;
        heroRef.current.style.transform = `rotateY(${moveX}deg) rotateX(${-moveY}deg)`;
      }
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);
    handleScroll();
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const products = [
    {
      id: 1,
      name: 'Gobelet Classique',
      price: '24,99 €',
      image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1920',
      description: 'Gobelet en acier inoxydable avec finition brossée élégante'
    },
    {
      id: 2,
      name: 'Gobelet Royal',
      price: '34,99 €',
      image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1920',
      description: 'Gobelet premium avec gravures artisanales'
    },
    {
      id: 3,
      name: 'Ensemble Duo',
      price: '44,99 €',
      image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1920',
      description: 'Ensemble de deux gobelets assortis avec étui en cuir'
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-500 ${
        isScrolled ? 'bg-black/80 glass-effect' : 'bg-transparent'
      }`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Wine className="w-8 h-8 feature-icon" />
            <div className="flex space-x-8">
              <a href="#" className="hover:opacity-75 transition-all duration-300 hover:scale-110">Collection</a>
              <a href="#" className="hover:opacity-75 transition-all duration-300 hover:scale-110">À propos</a>
              <a href="#" className="hover:opacity-75 transition-all duration-300 hover:scale-110">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header 
        ref={heroRef}
        className="relative h-screen bg-cover bg-center parallax-section transition-transform duration-300 ease-out" 
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1574226516831-e1dff420e562?auto=format&fit=crop&q=80&w=1920")'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black">
          <div className="container mx-auto px-4 h-full flex items-center">
            <div className="hero-text max-w-4xl" style={{ animationDelay: '0.3s' }}>
              <h1 className="text-8xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300">
                Gobelets en Acier d'Exception
              </h1>
              <p className="text-2xl mb-12 max-w-2xl text-gray-200">
                Découvrez notre collection de gobelets en acier inoxydable, où l'art rencontre la durabilité.
              </p>
              <button className="button-3d bg-white text-black px-12 py-4 rounded-full text-lg font-semibold">
                Explorer la Collection
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Features */}
      <section className="py-32 bg-gradient-to-b from-black via-gray-900 to-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16">
            {[
              { icon: ShieldCheck, title: 'Qualité Premium', desc: 'Acier inoxydable 18/10 de haute qualité' },
              { icon: Wine, title: 'Design Élégant', desc: 'Finitions soignées et style intemporel' },
              { icon: Truck, title: 'Livraison Rapide', desc: 'Expédition sous 24h en France' },
              { icon: Clock4, title: 'Garantie à Vie', desc: 'Satisfaction garantie ou remboursé' }
            ].map((feature, index) => (
              <div
                key={index}
                ref={el => featureRefs.current[index] = el}
                className="scroll-reveal flex flex-col items-center text-center"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <feature.icon className="w-16 h-16 mb-6 feature-icon text-white" />
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-400">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-32 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-6xl font-bold text-center mb-20 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
            Notre Collection
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {products.map((product, index) => (
              <div
                key={product.id}
                ref={el => productRefs.current[index] = el}
                className="product-card scroll-reveal bg-gray-900 rounded-2xl overflow-hidden"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="relative overflow-hidden">
                  <img src={product.image} alt={product.name} className="w-full h-80 object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-semibold mb-3">{product.name}</h3>
                  <p className="text-gray-400 mb-6">{product.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
                      {product.price}
                    </span>
                    <button className="button-3d bg-white text-black px-8 py-3 rounded-full font-semibold">
                      Ajouter
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
            <div>
              <h4 className="text-xl font-semibold mb-6">À Propos</h4>
              <p className="text-gray-400">Spécialiste des gobelets en acier depuis 2020. Qualité et élégance garanties.</p>
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-6">Contact</h4>
              <p className="text-gray-400">Email: contact@gobelets.fr</p>
              <p className="text-gray-400">Tél: 01 23 45 67 89</p>
            </div>
            <div>
              <h4 className="text-xl font-semibold mb-6">Newsletter</h4>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Votre email"
                  className="flex-1 px-6 py-3 rounded-l-full bg-black text-white border-2 border-gray-800 focus:outline-none focus:border-white transition-colors"
                />
                <button className="button-3d bg-white text-black px-8 py-3 rounded-r-full font-semibold">
                  S'inscrire
                </button>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;